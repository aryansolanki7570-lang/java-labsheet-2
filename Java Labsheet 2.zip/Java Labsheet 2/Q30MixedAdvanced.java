import java.util.Scanner;
public class Q30MixedAdvanced {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = sc.nextInt();
        boolean isPowerOf4 = false;
        if (number > 0) {
            int temp = number;
            while ((temp & 1) == 0) {
                temp = temp >> 1;
            }
            if (temp == 1 && (number & 0x55555555) != 0) {
                isPowerOf4 = true;
            }
        }
        if (isPowerOf4) {
            System.out.println(number + " is a power of 4.");
        } else {
            System.out.println(number + " is not a power of 4.");
        }

        int toggledNumber = number ^ (1 << 2);
        System.out.println("Number after toggling 3rd bit: " + toggledNumber);
        System.out.println("Multiplication table:");
        for (int i = 1; i <= 10; i++) {
            int result = number * i;
            if (result % 6 == 0) {
                continue;
            }
            if (result % 48 == 0) {
                break;
            }
            System.out.println(number + " x " + i + " = " + result);
        }
        sc.close();
    }
}
