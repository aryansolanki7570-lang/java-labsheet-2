import java.util.Scanner;
public class Q28Continue {
    public static void main(String[] args) {
        System.out.println("Numbers from 1 to 50, skipping multiples of 5:");
        for (int i = 1; i <= 50; i++) {
            if (i % 5 == 0) {
                continue;
            }
            System.out.print(i + " ");
        }
    }
}
