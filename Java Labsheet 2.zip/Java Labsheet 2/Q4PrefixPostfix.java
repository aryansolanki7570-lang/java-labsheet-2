import java.util.Scanner;
public class Q4PrefixPostfix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int visitors = 0;
        System.out.print("Enter visitors entering the store: ");
        int entering = sc.nextInt();

        System.out.print("Enter visitors leaving the store: ");
        int leaving = sc.nextInt();

        for (int i = 0; i < entering; i++) {
            ++visitors;
        }
        for (int i = 0; i < leaving; i++) {
            visitors--;
        }
        System.out.println("Visitors currently in store: " + visitors);
        int counter = 0;

        System.out.println("Postfix increment: " + counter++);
        System.out.println("After postfix increment: " + counter);
        System.out.println("Prefix increment: " + ++counter);
        sc.close();
    }
}
