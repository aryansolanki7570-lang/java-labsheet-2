import java.util.Scanner;
public class Q24MaxMinArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter array size: ");
        int size = sc.nextInt();
        int[] numbers = new int[size];
        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = sc.nextInt();
        }
        int maximum = numbers[0];
        int minimum = numbers[0];
        for (int number : numbers) {
            if (number > maximum) {
                maximum = number;
            }
            if (number < minimum) {
                minimum = number;
            }
        }
        System.out.println("Maximum value: " + maximum);
        System.out.println("Minimum value: " + minimum);
        sc.close();
    }
}
