import java.util.Scanner;
public class Q16ShiftOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = sc.nextInt();
        System.out.print("Enter power of 2: ");
        int power = sc.nextInt();
        int multiplication = number << power;
        int division = number >> power;
        System.out.println("After multiplication by 2^" + power + ": " + multiplication);
        System.out.println("After division by 2^" + power + ": " + division);
        sc.close();
    }
}
